﻿using System;
using Entidades;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        [ExpectedException (typeof(NoAgregaException))]
        public void NoAgregaException()
        {
            //Arrange
            Fruta v1 = new Fruta((float)2.5, ReinoVegetal.Gusto.Dulce, ConsoleColor.Red);
            Fruta v2 = new Fruta((float)12.5, ReinoVegetal.Gusto.Dulce, ConsoleColor.Blue);

            Canasta<Fruta> canasta1 = new Canasta<Fruta>(1);

            //Act
            canasta1 += v1;
            canasta1 = canasta1 + v2;

            //Assert handled by Expected Exception
        }
    }
}
