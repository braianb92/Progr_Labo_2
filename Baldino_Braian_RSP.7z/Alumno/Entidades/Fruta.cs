﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Entidades
{
    [Serializable]
    [XmlInclude(typeof(ReinoVegetal))]
    public class Fruta : ReinoVegetal, IVegetales
    {
        #region Atributes
        public ConsoleColor color;
        #endregion

        #region Propiedades
        public ConsoleColor Color
        {
            get { return this.color; }
        }

        public float Valor
        {
            get { return this.valor; }
        }

        public Gusto GustoFruta
        {
            get { return this.gusto; }
        }
        #endregion

        #region Constr.
        public Fruta() : base() { }

        public Fruta(float valor, Gusto gusto, ConsoleColor color) : base(valor,gusto)
        {
            this.color = color;
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.AppendLine($"Color: {this.Color.ToString()}");
            return sb.ToString();
        }

        public string MostrarDatos()
        {
            return ToString();
        }

        public string MostrarElemento()
        {
            if (GuardarElemento.Guardar(this))
                return this.MostrarDatos();
            else
                throw new Exception("Error al guardar  archivos y mostrar elemento");
        }

        #endregion

       


    }
}
