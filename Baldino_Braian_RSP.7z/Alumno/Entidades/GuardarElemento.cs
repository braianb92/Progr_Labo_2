﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Entidades
{
    public static class GuardarElemento
    {
        #region Extension Method
        public static bool Guardar(this Fruta elemento)
        {

            if (GuardarElemento.GuardarXml("datos.xml", elemento) &&
                GuardarElemento.GuardarBinaryXml("datos.bin", elemento) &&
                GuardarElemento.GuardarTexto("datos.txt", elemento.MostrarDatos()))
                return true;
            return false;
        }

        private static bool GuardarXml(string fileName, Fruta datos)
        {
            if (!string.IsNullOrEmpty(fileName) && !ReferenceEquals(datos, null))
            {
                try
                {
                    string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                    XmlTextWriter xmlWriter = new XmlTextWriter(Path.Combine(desktop + "/" + fileName), Encoding.UTF8);
                    XmlSerializer serializer = new XmlSerializer(typeof(Fruta));

                    serializer.Serialize(xmlWriter, datos);
                    xmlWriter.Close();
                    return true;
                }
                catch (Exception e)
                {
                    throw new Exception("Error en serializacion datos.xml", e);
                }
            }
            return false;
        }

        private static bool GuardarTexto(string archivo, string datos)
        {
            bool aux = false;
            if (!string.IsNullOrEmpty(archivo) && !string.IsNullOrEmpty(datos))
            {
                try
                {
                    string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                    StreamWriter sw = new StreamWriter(Path.Combine(desktop, archivo));
                    sw.WriteLine(datos);
                    sw.Close();
                    aux = true;
                }
                catch (Exception e)
                {
                    throw new Exception("Error datos.txt",e);
                }
            }

            return aux;
        }

        public static bool GuardarBinaryXml(string archivo, Fruta datos)
        {
            bool retorno = false;
            if (!string.IsNullOrEmpty(archivo) && !ReferenceEquals(datos, null))
            {
                try
                {
                    string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                    FileStream fs = new FileStream(Path.Combine(desktop, archivo), FileMode.Create);
                    BinaryFormatter ser = new BinaryFormatter();

                    ser.Serialize(fs, datos);
                    fs.Close();
                    retorno = true;
                }
                catch (Exception ex)
                {

                    throw new Exception("Error Serializacion binaria.", ex);
                }
            }
            return retorno;
        }
        #endregion
    }
}
