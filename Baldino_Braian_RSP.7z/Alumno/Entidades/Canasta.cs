﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Canasta<T> where T : IVegetales
    {
        #region Atributes
        private List<T> plantas;
        private short capacidad;
        #endregion

        #region Constr.
        private Canasta()
        {
            this.plantas = new List<T>();
        }

        public Canasta(short capacidad):this()
        {
            this.capacidad = capacidad;
        }
        #endregion

        #region Operator overload
        public static Canasta<T> operator + (Canasta<T> c, ReinoVegetal reinoVegetal)
        {
            if (reinoVegetal is T)
            {
                if (c.plantas.Count < c.capacidad)
                {
                    T aux = (T)Convert.ChangeType(reinoVegetal, typeof(T));
                    c.plantas.Add(aux);

                    return c;
                }
                else
                {
                    // Lanzar excepción con el mensaje "Capacidad excedida."
                    throw new NoAgregaException("Capacidad excedida");
                }
            }
            else
            {
                // Lanzar excepción con el mensaje "El elemento es del tipo {0}. Se esperaba {1}."
                throw new NoAgregaException($"El elemento es del tipo {reinoVegetal.GetType()}. Se esperaba {typeof(T)}.");
            }
        }
        #endregion

        #region Override 
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Capacidad: " + this.capacidad);
            foreach (T reinoVegetal in this.plantas)
            {
                sb.AppendLine(reinoVegetal.ToString());
            }
            return sb.ToString();
        }
        #endregion
    }
}
