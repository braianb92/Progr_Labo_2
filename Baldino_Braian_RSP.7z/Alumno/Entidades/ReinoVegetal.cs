﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Entidades
{
    [Serializable]
    public abstract class ReinoVegetal
    {
        #region Enum
        // Tipos del enumerado Dulce, Salado, Toxica
        public enum Gusto
        {
            Dulce,
            Salado,
            Toxica
        }
        #endregion

        #region Atributes
         private static Random calcularValor;
        protected float valor;
        protected Gusto gusto;
        #endregion

        #region Constr.
        static ReinoVegetal()
        {
            calcularValor = new Random();
        }

        public ReinoVegetal() { }

        public ReinoVegetal(Gusto gusto)
        {
            this.valor = calcularValor.Next(1, 100);
        }

        public ReinoVegetal(float valor, Gusto gusto)
        {
            this.valor = valor;
            this.gusto = gusto;
        }
        #endregion

        #region Methods
        /// <summary>
        /// Devuelve el valor y gusto (ReinoVegetal)
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Valor: {this.valor}");
            sb.AppendLine($"Gusto: {this.gusto}");
            return sb.ToString();
        }
        #endregion

        #region Operator Overloads
        public static bool operator == (ReinoVegetal v1, ReinoVegetal v2)
        {

            if (v1.GetType() == v2.GetType() && v1.gusto == v2.gusto)
                return true;
            else
                return false;
        }

        public static bool operator !=(ReinoVegetal v1, ReinoVegetal v2)
        {
            return !(v1==v2);
        }
        #endregion

    }
}
