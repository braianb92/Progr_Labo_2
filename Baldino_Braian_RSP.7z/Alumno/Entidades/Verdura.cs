﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Verdura : ReinoVegetal , IVegetales
    {
        #region Enum
        // Tipos del enumerado Semilla, Raíz, Tubérculo, Bulbo, Tallo, Hoja, Inflorescencia, Rizoma
        public enum TipoVerdura
        {
            Semilla,
            Raíz,
            Tubérculo,
            Bulbo,
            Tallo,
            Hoja,
            Inflorescencia,
            Rizoma
        }
        #endregion

        #region Atributes
        private TipoVerdura tipo;
        #endregion

        #region Propiedades
        public TipoVerdura Tipo
        {
            get { return this.tipo; }
        }
        #endregion

        #region Constr.
        public Verdura(float valor, Gusto gusto, TipoVerdura tipo) : base(valor,gusto)
        {
            this.tipo = tipo;
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.AppendLine($"Tipo: {this.Tipo.ToString()}");
            return sb.ToString();
        }

        public string MostrarDatos()
        {
            return ToString();
        }
        #endregion

       
    }
}
